import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import AboutImag from "../assets/tech3.jpg";
import Footer from "../components/Footer";
import Trip from "../components/Trip";
function Service() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero-mid"
        heroImg={AboutImag}
        title="My works"
        btnclass="hide"
      />
      <Trip />
      <Footer />
    </>
  );
}
export default Service;
