import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import AboutImag from "../assets/tech4.jpg";
import Footer from "../components/Footer";
import AboutUs from "../components/AboutUs";
function About() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero-mid"
        heroImg={AboutImag}
        title="About"
        btnclass="hide"
      />
      <AboutUs />
      <Footer />
    </>
  );
}
export default About;
