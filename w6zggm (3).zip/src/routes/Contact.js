import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import AboutImag from "../assets/tech5.jpg";
function Contact() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero-mid"
        heroImg={AboutImag}
        title="Contact"
        btnclass="hide"
      />
    </>
  );
}
export default Contact;
