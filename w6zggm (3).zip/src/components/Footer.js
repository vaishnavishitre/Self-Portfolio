import "./FooterStyles.css";
const Footer = () => {
  return (
    <div className="footer">
      <div className="top">
        <div>
          <h1>Portfolio</h1>
          <p>
            1. Privacy Policy | Terms of Service | Contact Us 2. About Us |
            Careers | FAQ 3. Social Media | Accessibility | Copyright Notice 4.
            Subscribe to our Newsletter | Feedback | Partnerships 5. Blog | Site
            Map | Disclaimer
          </p>
        </div>
        <div>
          <a href="/">
            <i className="fa-brands fa-facebook-square"></i>
          </a>
          <a href="/">
            <i className="fa-brands fa-behance-square"></i>
          </a>
          <a href="/">
            <i className="fa-brands fa-instagram-square"></i>
          </a>
          <a href="/">
            <i className="fa-brands fa-twitter-square"></i>
          </a>
        </div>
      </div>
      <div className="bottom">
        <div>
          <h4>facebook</h4>
          <a href="/"></a>
          <a href="/"></a>
          <a href="/"></a>
          <a href="/"></a>
        </div>
        <div>
          <h4>Contacts</h4>
          <a href="/">WhatsApp-7400374951</a>
          <a href="/">---</a>
          <a href="/">--</a>
          <a href="/">--</a>
        </div>
        <div>
          <h4>LinkedIn</h4>
          <a href="/">https: //www.linkedin.com/ vaishnavi-shitre -03145022a</a>
          <a href="/">--</a>
          <a href="/">--</a>
          <a href="/">--</a>
        </div>
        <div>
          <h4>Extra</h4>
          <a href="/">//</a>
          <a href="/">//</a>
          <a href="/">//</a>
          <a href="/">//</a>
        </div>
      </div>
    </div>
  );
};
export default Footer;
