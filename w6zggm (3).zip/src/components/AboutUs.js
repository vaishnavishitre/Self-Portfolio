import "./ABoutUsStyles.css";
function AboutUs() {
  return (
    <div className="about-container">
      <h1>Name: Vaishnavi Suresh Shitre
          Gender: female
          Age:20
      </h1>
      <p>Hello! I am a passionate and dedicated female Computer Science student eagerly seeking an internship opportunity to apply my knowledge and skills. With a solid foundation in Python, JavaScript, React, and C programming, I have honed my abilities to develop robust and efficient applications. My understanding of data structures enables me to create optimized solutions to complex problems, and I thrive on challenges that demand creativity and critical thinking. Throughout my academic journey, I have actively participated in various coding competitions and collaborative projects, fostering my ability to work harmoniously in a team. As an aspiring developer, I am committed to leveraging technology to build innovative solutions that make a positive impact on users' lives. I am excited about the prospect of joining a dynamic team and contributing my expertise to real-world projects during this internship.</p>
    
    </div>
  );
}
export default AboutUs;
