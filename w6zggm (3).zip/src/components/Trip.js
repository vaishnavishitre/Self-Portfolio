import TripData from "./TripData";
import "./TripStyles.css";
import Trip1 from "../assets/tech8.jpg";
import Trip2 from "../assets/tech7.jpg";
import Trip3 from "../assets/tech9.jpg";
function Trip() {
  return (
    <div className="trip">
      <h1>Recent projects</h1>
      <p>This are some projects i did over the years..</p>
      <div className="tripcard">
        <TripData
          image={Trip1}
          heading="PYthon AI assitant"
          text="Welcome to the world of innovation and convenience!MY Python AI Voice Assistant project is a cutting-edge endeavor that combines the power of artificial intelligence and natural language processing to create a seamless and intuitive user experience. Powered by Python's robust libraries and frameworks, our voice assistant is designed to understand and respond to user commands, whether it's providing weather updates, answering questions, setting reminders, or even controlling smart home devices. With a focus on continuous learning and adaptation, our voice assistant strives to improve its capabilities over time, making it an indispensable companion for users in their daily tasks and enhancing their interaction with technology through the power of speech. Get ready to embark on a journey of hands-free productivity and efficiency with our Python AI Voice Assistant!"
        />
        <TripData
          image={Trip2}
          heading="Reactjs Website"
          text="Welcome to our ReactJS website project, where i blend the power of modern web development with seamless user experiences! With ReactJS as our core technology, we are crafting a dynamic and interactive website that delivers unparalleled responsiveness and speed. Leveraging React's component-based architecture, we ensure smooth navigation and real-time updates, providing visitors with an engaging and fluid browsing experience. Whether it's showcasing products, sharing compelling content, or facilitating seamless interactions, our ReactJS website project is dedicated to delivering a visually stunning and user-friendly platform that leaves a lasting impression on users and reflects the cutting-edge potential of web development. Get ready to explore the future of web experiences with our ReactJS-powered website!"
        />
        <TripData
          image={Trip3}
          heading="Online Food Delivery"
          text="Step into the world of convenience and gastronomic delights with our online food delivery website project, meticulously crafted with the perfect blend of PHP, HTML, and CSS. Seamlessly connecting food enthusiasts with their favorite eateries, our platform offers a user-friendly interface that enables customers to explore a diverse menu, place orders, and have their favorite dishes delivered right to their doorstep. With PHP's robust backend capabilities, we ensure secure and efficient order processing, while HTML and CSS work together harmoniously to create an appealing and intuitive design that enhances the overall user experience. Whether you're craving comfort food or seeking culinary adventures, our online food delivery website promises to be the go-to destination, revolutionizing the way you savor your favorite meals from the comfort of your home. Bon appétit!"
        />
      </div>
    </div>
  );
}
export default Trip;
