import Mountain1 from "../assets/tech1.jpg";
import Mountain2 from "../assets/tech2.jpg";
import Mountain3 from "../assets/tech3.jpg";
import Mountain4 from "../assets/tech4.jpg";
import "./DestinationStyles.css";
import DestinationData from "./DestinationData";

const Destination = () => {
  return (
    <div className="destination">
      <h1>HOME PAGE TO MY PORTFOLIO</h1>
      <p>Self Introduction</p>

      <DestinationData
        className="first-des"
        heading="WELCOME"
        text="
         My name is Vaishnavi Suresh Shitre. I am a student at 
         Mumbai university Majors in computer Science a bachelors
         degree. I have a keen interest in designing and technology
         i seek intellgence in Python programming language,C language
         Data strcture and Data Science. I made this website
         with the help of JS and React."
        img1={Mountain1}
        img2={Mountain2}
      />
      <DestinationData
        className="first-des-reverse"
        heading="WELCOME"
        text="
        Greetings! I am a passionate and driven Computer Science student on a quest to unravel the mysteries of technology. With a deep-rooted fascination for coding, problem-solving, and innovation, I find myself constantly exploring the ever-evolving world of computer science. My insatiable curiosity drives me to learn new programming languages, algorithms, and data structures, while my determination to make a positive impact pushes me to tackle real-world challenges through software development. As I embark on this thrilling journey, I am excited to leverage my skills, creativity, and collaborative spirit to contribute meaningfully to the world of technology and beyond."
        img1={Mountain3}
        img2={Mountain4}
      />
    </div>
  );
};
export default Destination;
